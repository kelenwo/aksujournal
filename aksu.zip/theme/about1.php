<section id="center" class="center_home" style="background-color: #def7de;">
  <div class="container">
  <div class="row">
 
   <div class="center_home_2 clearfix">

	<div class="col-sm-12 col-xs-12" style="">
	 <div class="center_home_2_inner_1 clearfix" style="text-align: center;color: #000">
    <h1>Who we are</h1>
	 <hr>	
	 <div class="center_home_2_inner_1_inner clearfix" style="margin:0 30px 0 25px; text-align: justify;">	
	 <p>AKSU Journal of Agricultural Economics and Extension (AKSUJAEERD) is a peer- reviewed open- access Journal, a publication of the Department of Agricultural Economics and Extension – Akwa Ibom State University, Nigeria. AKSUJAEERD is published in both ONLINE (electronic) and PRINT (hard-copy) versions. The journal aims to publish high quality scientific papers in all areas of Agricultural Economics (Farm Management and Production Economics, Agricultural Marketing and Agribusiness, Agricultural Finance and Project Analysis, Agricultural Cooperatives, Agricultural policy, Planning and Development, Resource and Environmental Economics, Food and Welfare Economics etc.), Extension and Rural Development (Extension Education/Administration, Agricultural Communication, Sociology and Rural Development etc.). The emphasis is on both quantitative and qualitative works which are novels and of policy relevance. The papers are published in the English language. The Journal is published three times per year (April, August and December) and the following types of contributions are published: Original scientific paper, Review articles and Short communications. These papers are reviewed by eminent scientists.</p>


	   	
	
      	   </div>
	   <hr>

		</div>
	 </div>
	</div>
   </div>
  </div>

</section>

