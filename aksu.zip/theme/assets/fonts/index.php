
       <div class="home-sec" id="home" >
           <div class="overlay">
 <div class="container">
           <div class="row text-center " >

               <div class="col-lg-12  col-md-12 col-sm-12">

                <div class="flexslider set-flexi" id="main-section" >
                    <ul class="slides move-me">
                        <!-- Slider 01 -->
                        <li>
                              <h3>Delivering Quality Education</h3>
                           <h1>THE UNIQUE METHOD</h1>

                        </li>
                        <!-- End Slider 01 -->

                        <!-- Slider 02 -->
                        <li>
                            <h3>Delivering Quality Education</h3>
                           <h1>UNMATCHED APPROACH</h1>

                        </li>
                        <!-- End Slider 02 -->

                        <!-- Slider 03 -->
                        <li>
                            <h3>Delivering Quality Education</h3>
                           <h1>AWESOME FACULTY PANEL</h1>

                        </li>
                        <!-- End Slider 03 -->
                    </ul>
                </div>




            </div>

               </div>
                </div>
           </div>

       </div>
       <!--HOME SECTION END-->
    <div  class="tag-line" >
         <div class="container">
           <div class="row text-center">

               <div class="col-lg-12  col-md-12 col-sm-12">

        <h2 data-scroll-reveal="enter from the bottom after 0.1s" ><i class="fa fa-gear spin"></i>FACULTY OF ENGINEERING - UNIUYO <i class="fa fa-gear spin"></i> </h2>
                   </div>
               </div>
             </div>

    </div>
    <!--HOME SECTION TAG LINE END-->
         <div id="features-sec" class="container set-pad" >
                   <div class="row text-center">
                 <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                     <h1 data-scroll-reveal="enter from the bottom after 0.1s"  class="header-line">WELCOME </h1>
                     <p data-scroll-reveal="enter from the bottom after 0.1s" >
                      At NUESA, we help you unleash your potential with programs like the Technical Network where we combine creativity with innovation.
                      Welcome to the home of intelligent people, things. It is greatness unveiled!
                         </p>
                 </div>

             </div>
             <!--/.HEADER LINE END-->


           <div class="row" >


                 <div class="col-lg-  col-md- col-sm-" data-scroll-reveal="enter from the bottom after 0.4s">

                   </div>
                   <div class="col-lg-12  text-center col-md-12 col-sm-12" data-scroll-reveal="enter from the bottom after 0.5s">
                     <div class="col-md-11 about-contant">

                  <div class="row">
                      <div class="col-md-4 col-sm-4 m-b15">
                          <div class="icon-bx-wraper bx-style-1 p-tb15 p-lr10 center">
                              <div class="icon-bx-sm radius lnk1 bg-primary m-b5">
                                <a class="icon-cell"><i class="fa fa-home"></i></a></div>
                              <div class="icon-content">
                                  <h5 class="h5 text-primary"><span class="counter">1</span></h5>
                                  <p>Faculty</p>
                              </div>
                          </div>
                      </div>
                      <div class="col-md-4 col-sm-4 m-b15">
                          <div class="icon-bx-wraper bx-style-1 p-tb15 p-lr10 center">
                              <div class="icon-bx-sm radius lnk1 bg-primary m-b5">
                                <a class="icon-cell"><i class="fa fa-building"></i></a></div>
                              <div class="icon-content">
                                  <h5 class="h5 text-primary"><span class="counter">8</span>
                                  </h5>
                                  <p>Departments</p>
                              </div>
                          </div>
                      </div>
                      <div class="col-md-4 col-sm-4 m-b15">
                          <div class="icon-bx-wraper bx-style-1 p-tb15 p-lr10 center">
                              <div class="icon-bx-sm radius lnk1 bg-primary m-b5">
                                <a class="icon-cell"><i class="fa fa-user"></i></a></div>
                              <div class="icon-content">
                                  <h5 class="h5 text-primary"><span class="counter">3000</span>+
                                  </h5>
                                  <p>Students</p>
                              </div>
                          </div>
                      </div>
                  </div>

              </div>
                   </div>

</div></div>

   <!-- FEATURES SECTION END-->
   <div class="lnk1 img-bg p-tb30" style="">
               <div class="container">
                   <h6 class="h6-s inline">PROVIDING THE WORLD WITH QUALITY ENGINEERS SINCE 1995</h6>
                   <div class="pull-right site-button"><a href="/about" class="btn btn-lg btn-default">Learn more <i class="fa fa-arrow-circle-o-right text-secondry "></i></a></div>
               </div>
           </div>
    <!-- FACULTY SECTION END-->
      <div id="course-sec" class="container set-pad">
             <div class="row text-center">
                 <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                     <h1 data-scroll-reveal="enter from the bottom after 0.1s" class="header-line">GALLERY </h1>

                 </div>

             </div>
           </div>
             <!--/.HEADER LINE END-->

                          <div class="container">
                            <div class="row text-center">
                            <div class="col-lg-12  col-md-12 col-sm-12">
                              <div class="slide-container">
                              <div class="main-content"> </div>
                              <div class="left-arrow"><i class="fa fa-arrow-left"></i> </div>
                              <div class="right-arrow"><i class="fa fa-arrow-right"></i></div>

                              <div class="captionText" id="captionText"></div>

                              </div>

                                <div class="dot-container"> </div>
                         </div>

                            </div>
                          </div>

      <!-- COURSES SECTION END-->
      <div id="course-sec" class="container set-pad">
             <div class="row text-center">
                 <div class="col-lg-8 col-lg-offset-2 col-md-8 col-sm-8 col-md-offset-2 col-sm-offset-2">
                     <h1 data-scroll-reveal="enter from the bottom after 0.1s" class="header-line">SPOTLIGHT </h1>

                 </div>

             </div>
           </div>
           <div class="container">
             <div class="row text-center">
             <div class="">
               <div class="col-lg-4 col-md-4 col-sm-6 m-b15">
                <div class="spot">
                  <div class="overlay">
                  <img src="theme/assets/img/faculty/dean.jpg">
                  <div class="cap">
                     <h5 class="h6-s">Prof. Aniekan Offiong</h5>
                     <h5 class="white">Dean of Faculty</h5>
                   </div>
                 </div>
                </div>
               </div>
               <div class="col-lg-4 col-md-4 col-sm-6 m-b15">
                 <div class="spot">
                   <div class="overlay">
                   <img src="theme/assets/img/faculty/3.jpg">
                   <div class="cap">
                      <h5 class="h6-s">Mr. Sammuel Effiok</h5>
                      <h5 class="white">Faculty Officer</hs>
                    </div>
                 </div>
               </div>

               </div>
               <div class="col-lg-4 col-md-4 col-sm-6 m-b15">
                 <div class="spot">
                   <div class="overlay">
                   <img src="theme/assets/img/faculty/usanga.jpg">
                   <div class="cap">
                      <h5 class="h6-s">Precious Usanga</h5>
                      <h5 class="white">Faculty President</h5>
                    </div>
                 </div>
               </div>
               </div>
          </div>

             </div>
           </div>



<style>

.slide-container {
margin: 5%;
position: relative;
align-items: center;
}
.slide-container img {
  height: 100% !important;
  width: 100% !important;
}
.slide-container i {
  font-size: 25px;
  color: black;
  font-weight: 900;
}
.left-arrow {
width:100px;
height:100%;
position:absolute;
top:0;
left:0;
}

.right-arrow {
width:100px;
height:100%;
position:absolute;
top:0;
right:0;
}

.left-arrow>i {
position:relative;
top:40%;
transform:translateY(-50%);
margin-left:-70px;
transition:opacity 1s;
}

.right-arrow>i {
position:relative;
top:40%;
transform:translateY(-50%);
margin-left:72px;
transition:opacity 1s;
}

.left-arrow>i:hover,.right-arrow>i:hover {
cursor:pointer;
}

.dot-container {
  margin-top: 8px;
position:relative;
left:50%;
transform:translateX(-50%);
bottom:50px;
}

.dot {
cursor:pointer;
height:10px;
width:10px;
background-color: #eee;
border: 1px #000 solid;
border-radius:0;
display:inline-block;
transition:background-color .6s ease;
margin:0 2px;
}


.active,.dot:hover {
background-color:rgba(243,189,43,1);
border: 1px;
height:12px;
width:12px;
}

.captionText {
width:100%;
height:50px;
position:relative;
font-family: cursive;
bottom: 50px;
font-size:16px;
font-weight:500;
text-align:center;
line-height:auto;
letter-spacing:.19em;
background-color:rgba(40,40,40,0.5);
color:#fff;
}

.main-content,.responsive-img {
width:100%;
height:100%;
}




</style>
      <script>
      $(document).ready(function(){

      //add image links below

      var images= [];
      images[0]= 'theme/assets/img/images(1).jpg';
      images[1]= 'theme/assets/img/contact.jpg';
      images[2]= 'theme/assets/img/building.jpg';
      images[3]= 'theme/assets/img/contact.jpg';
      images[4]= 'theme/assets/img/building.jpg';

      //add caption text

      var capTexts= [];
      capTexts[0]= 'Building of the entire school';
      capTexts[1]= 'Student learning in the library';
      capTexts[2]= 'Main campus building';
      capTexts[3]= 'Caption Text';
      capTexts[4]= 'Caption Text';


      //3000 miliseconds=3 seconds
      //set time

      var pausebetweenimages=10000;

      var count=0;
      var imageCount= images.length-1;

      //creating navigation dots

      var navDots= [];

      for(var i=0; i<imageCount+1; i++)
      {
      navDots[i]='<div class="dot"></div>';
      $('.dot-container').append(navDots[i]);
      }

      $('.main-content').html('<img src=' + images[count] +'>');

      //adding .responsive-img class to set image's width and height 100%

      $('.main-content > img').addClass('responsive-img');

      //adding .active class to current navigation dot's index

      $( '.dot' ).eq(count).addClass('active');

      //animating caption text


      $('#captionText').text(capTexts[count]);

      //fucntion that will run a certain time intervals

      timingRun = setInterval(function(){ sliderTiming();}, pausebetweenimages);

      function sliderTiming ()
      {
      $( '.dot' ).eq(count).removeClass('active');
      count++;

      if(count>imageCount)
      {
      count=0;
      }

      //fadein and fadeout effect

      $('.main-content').fadeOut(100,function () {
      $('.main-content').html('<img src=' + images[count] +'>');
      $('.main-content > img').addClass('responsive-img');
      $( '.dot' ).eq(count).addClass('active');
      $('.main-content').fadeIn(500);

      captextAnim_Responsive();
      });
      }


      $('.right-arrow>i').click(function(){
      $( '.dot' ).eq(count).removeClass('active');
      count++;
      if(count>imageCount)
      {
      count=0;
      }
      $('.main-content').fadeOut(100, function () {
      $('.main-content').html('<img src=' + images[count] +'>');
      $('.main-content > img').addClass('responsive-img');
      $( '.dot' ).eq(count).addClass('active');
      $('.main-content').fadeIn(500);

      captextAnim_Responsive();
      });
      resetTiming();
      });

      $('.left-arrow>i').click(function(){
      $( '.dot' ).eq(count).removeClass('active');
      count--;
      if(count<0)
      {
      count=imageCount;
      }
      $('.main-content').fadeOut(100, function () {
      $('.main-content').html('<img src=' + images[count] +'>');
      $('.main-content > img').addClass('responsive-img');
      $( '.dot' ).eq(count).addClass('active');
      $('.main-content').fadeIn(500);

      captextAnim_Responsive();
      });
      resetTiming();
      });

      $('.dot').click(function () {
      $( '.dot' ).eq(count).removeClass('active');
      count= $(this).index();
      $('.main-content').fadeOut(100,function () {
      $('.main-content').html('<img src=' + images[count] +'>');
      $('.main-content > img').addClass('responsive-img');
      $( '.dot' ).eq(count).addClass('active');
      $('.main-content').fadeIn(500);

      captextAnim_Responsive();
      });
      resetTiming();
      });

      //reset the time interval

      function resetTiming() {
      clearInterval(timingRun);
      timingRun = setInterval(function() { sliderTiming(); },pausebetweenimages);
      }

      //animating caption text with responsiveness

      function captextAnim_Responsive(){
      if ($(window).width() <= 500)
      {
      $('#captionText').css('opacity', '0');
      $('#captionText').css('left', '0');
      $('#captionText').text(capTexts[count]);
      $('#captionText').animate({
      'opacity': '.8'
      }, 500);
      }

      else {
      $('#captionText').css('opacity', '0');
      $('#captionText').css('left', '0');
      $('#captionText').text(capTexts[count]);
      $('#captionText').animate({
      'opacity': '.8'
      }, 500);
      }
      }

      });
</script>
