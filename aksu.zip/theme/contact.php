<section id="center" class="center_home" style="background-color: #def7de;">
	<div class="container">
  		<div class="row">
   		<div class="center_home_2 clearfix">
				<div class="col-sm-12 col-xs-12" style="padding: 10px">
					&nbsp;&nbsp;&nbsp;&nbsp;
				</div>
				<div class="col-sm-12 col-xs-12" style="height: 400px">
	 				<div class="center_home_2_inner_1 clearfix" style="text-align: center;color: #000">
    					<h1>Contact Us</h1>
	 					<hr>	
	   					<div class="center_home_2_inner_1_inner clearfix" style="margin:0px; font-size: 25px;">	
	 							<p> Department of Agricultural Economics & Extension, Faculty of Agriculture, Akwa Ibom State University, Nigeria </p>
      	   			</div>
	   				<hr>
					</div>
	 			</div>
			</div>
   	</div>
  	</div>
</section>

