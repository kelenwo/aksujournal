<section id="center" class="center_home" style="background-color: #f5f9f5;">
	<div class="container">
		<div class="row">
			<div class="center_home_2 clearfix">
				<div class="col-sm-12 col-xs-12">
					<div class="center_home_2_inner_1 clearfix" style="text-align: center;color: #000">
    					<h1>Our Subject Areas</h1>
	 					<hr>	
	   					<div class="center_home_2_inner_1_inner clearfix" style="margin:0px; font-size: 25px;">		
      	   		</div>
	   					<hr>
					</div>
	 			</div>
			</div>
   		</div>
  	</div>
</section>

