<br>
<br>

<div class="navbar-fixed-bottom" id="footer">
      &copy 2018 XcurityLAbs | All Rights Reserved |  SAinT Kelvin
</div>
 <!-- FOOTER SECTION END-->

</body>
</html>
